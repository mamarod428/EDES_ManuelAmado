# El fichero saludo.py pedirá el nombre del usuario y lo mostrará por pantalla

nombre = input("¿Cuál es tu nombre? ")
print(f"Hola {nombre}!")